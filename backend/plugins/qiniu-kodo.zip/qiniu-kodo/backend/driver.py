"""
Qiniu Kodo Storage Driver

New plugin-based driver using qiniu SDK.
Supports imageView2 native image processing.
"""

from __future__ import annotations

import hashlib
import io
import mimetypes
import tempfile
import time
from datetime import datetime
from typing import TYPE_CHECKING, BinaryIO, Optional

import anyio
import httpx
import qiniu

from app.exceptions import StorageConfigError, StorageError, StorageNotFoundError
from app.storage.base import (
    FileInfo,
    StorageConfig,
    StorageDriver,
    StorageVisibility,
    UploadResult,
)

if TYPE_CHECKING:
    from app.utils.image import ImageProcessParams


class KodoStorageDriver(StorageDriver):
    """
    Qiniu Kodo object storage driver
    """
    name = "qiniu-kodo"
    display_name = "storage.driver.qiniu_kodo"
    config_schema = {
        "type": "object",
        "properties": {
            "root_path": {
                "type": "string",
                "title": "config.storage.kodo.bucket",
                "description": "config.storage.kodo.bucket_desc",
            },
            "base_url": {
                "type": "string",
                "title": "config.storage.kodo.base_url",
                "description": "config.storage.kodo.base_url_desc",
            },
            "access_key": {
                "type": "string",
                "title": "config.storage.kodo.access_key",
            },
            "secret_key": {
                "type": "string",
                "title": "config.storage.kodo.secret_key",
            },
            "prefix": {
                "type": "string",
                "title": "config.storage.kodo.prefix",
            },
            "is_private": {
                "type": "boolean",
                "title": "config.storage.kodo.is_private",
                "default": False,
            },
        },
        "required": ["root_path"],
    }

    MAX_PROCESS_SIZE = 20 * 1024 * 1024  # 20MB

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        options = config.options or {}
        self.bucket_name = options.get("bucket") or config.root_path
        if not self.bucket_name:
            raise StorageConfigError()
        ak = options.get("access_key")
        sk = options.get("secret_key")
        if not ak or not sk:
            raise StorageConfigError()
        self.auth = qiniu.Auth(ak, sk)
        self.base_url = config.base_url.rstrip("/") if config.base_url else None
        self.prefix = options.get("prefix", "").strip("/")
        self.is_private = bool(options.get("is_private", False))
        self.bucket_manager = qiniu.BucketManager(self.auth)

    def _key(self, path: str) -> str:
        clean = path.lstrip("/")
        return f"{self.prefix}/{clean}" if self.prefix else clean

    async def put(
        self,
        path: str,
        content: BinaryIO,
        mime_type: str | None = None,
        visibility: StorageVisibility = StorageVisibility.PRIVATE,
        metadata: dict | None = None,
    ) -> UploadResult:
        key = self._key(path)

        def _upload() -> tuple[int, str]:
            data = content.read()
            size = len(data)
            hasher = hashlib.md5(data)
            file_hash = hasher.hexdigest()
            token = self.auth.upload_token(self.bucket_name, key, 3600)
            ret, info = qiniu.put_data(token, key, data)
            if info.status_code != 200:
                raise StorageError()
            return size, file_hash

        size, file_hash = await anyio.to_thread.run_sync(_upload)
        final_mime_type = mime_type or mimetypes.guess_type(path)[0]
        return UploadResult(
            path=path,
            url=await self.get_url(path, visibility=visibility),
            size=size,
            hash=file_hash,
            mime_type=final_mime_type or "application/octet-stream",
            driver=self.name,
        )

    async def get(self, path: str) -> BinaryIO:
        url = await self.get_url(path)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url)
                if response.status_code == 404:
                    raise StorageNotFoundError()
                response.raise_for_status()
                return io.BytesIO(response.content)
        except (StorageNotFoundError, StorageError):
            raise
        except httpx.HTTPStatusError as exc:
            raise StorageError() from exc
        except httpx.RequestError as exc:
            raise StorageError() from exc

    async def delete(self, path: str) -> bool:
        key = self._key(path)

        def _delete() -> bool:
            ret, info = self.bucket_manager.delete(self.bucket_name, key)
            if info.status_code == 612:
                return False
            if info.status_code != 200:
                raise StorageError()
            return True

        return await anyio.to_thread.run_sync(_delete)

    async def exists(self, path: str) -> bool:
        key = self._key(path)

        def _exists() -> bool:
            ret, info = self.bucket_manager.stat(self.bucket_name, key)
            return info.status_code == 200

        return await anyio.to_thread.run_sync(_exists)

    async def get_url(
        self,
        path: str,
        expires: int = 3600,
        visibility: StorageVisibility | None = None,
    ) -> str:
        key = self._key(path)
        if not self.base_url:
            raise StorageConfigError()
        base = f"{self.base_url}/{key}"
        if self.is_private or (visibility and visibility == StorageVisibility.PRIVATE):
            return self.auth.private_download_url(base, expires=expires)
        return base

    async def get_info(self, path: str) -> Optional[FileInfo]:
        key = self._key(path)

        def _stat() -> Optional[FileInfo]:
            ret, info = self.bucket_manager.stat(self.bucket_name, key)
            if info.status_code != 200:
                return None
            size = ret.get("fsize", 0)
            mime = ret.get("mimeType", "application/octet-stream")
            put_time = ret.get("putTime", 0)
            last_modified = datetime.fromtimestamp(put_time / 10000000) if put_time else datetime.utcnow()
            return FileInfo(
                path=path,
                size=size,
                mime_type=mime,
                last_modified=last_modified,
                visibility=StorageVisibility.PRIVATE if self.is_private else StorageVisibility.PUBLIC,
                metadata={},
            )

        return await anyio.to_thread.run_sync(_stat)

    async def copy(self, source: str, destination: str) -> bool:
        src_key = self._key(source)
        dst_key = self._key(destination)

        def _copy() -> bool:
            ret, info = self.bucket_manager.copy(
                self.bucket_name, src_key,
                self.bucket_name, dst_key,
            )
            return info.status_code == 200

        return await anyio.to_thread.run_sync(_copy)

    async def move(self, source: str, destination: str) -> bool:
        src_key = self._key(source)
        dst_key = self._key(destination)

        def _move() -> bool:
            ret, info = self.bucket_manager.move(
                self.bucket_name, src_key,
                self.bucket_name, dst_key,
            )
            return info.status_code == 200

        return await anyio.to_thread.run_sync(_move)

    # ========== Image Processing ==========

    def _build_kodo_process_params(self, params: "ImageProcessParams") -> str:
        """Build Kodo imageView2 URL suffix"""
        mode_map = {
            "fit": 2,
            "fill": 1,
            "crop": 1,
            "pad": 2,
        }
        mode = mode_map.get(params.mode, 2)
        parts = [f"imageView2/{mode}"]
        if params.width:
            parts.append(f"w/{params.width}")
        if params.height:
            parts.append(f"h/{params.height}")
        if params.quality and params.quality < 100:
            parts.append(f"q/{params.quality}")
        if params.format:
            parts.append(f"format/{params.format}")
        return "/".join(parts)

    async def get_image_url(
        self,
        path: str,
        params: "ImageProcessParams",
        expires: int = 3600,
        visibility: StorageVisibility | None = None,
    ) -> str:
        if params.is_empty():
            return await self.get_url(path, expires=expires, visibility=visibility)

        info = await self.get_info(path)
        if info and info.size > self.MAX_PROCESS_SIZE:
            return await self.get_url(path, expires=expires, visibility=visibility)

        key = self._key(path)
        if not self.base_url:
            raise StorageConfigError()
        process_str = self._build_kodo_process_params(params)
        base = f"{self.base_url}/{key}?{process_str}"
        if self.is_private or (visibility and visibility == StorageVisibility.PRIVATE):
            return self.auth.private_download_url(base, expires=expires)
        return base

    async def get_processed_image(
        self,
        path: str,
        params: "ImageProcessParams",
    ) -> tuple[bytes, str] | None:
        if params.is_empty():
            return None
        from app.utils.image import ImageProcessor
        source = await self.get(path)
        return await ImageProcessor.process(source, params)

    def supports_native_image_processing(self) -> bool:
        return True
