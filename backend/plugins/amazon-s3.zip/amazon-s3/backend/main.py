"""
Amazon S3 Compatible Storage Plugin
"""

from app.plugins.base import PluginBase


class S3StoragePlugin(PluginBase):
    """S3 compatible storage driver plugin"""

    async def on_install(self, ctx) -> None:
        ctx.get_logger().info("S3 compatible storage plugin installed")

    async def on_enable(self, ctx) -> None:
        ctx.get_logger().info("S3 compatible storage plugin enabled")

    async def on_disable(self, ctx) -> None:
        ctx.get_logger().info("S3 compatible storage plugin disabled")

    async def on_uninstall(self, ctx) -> None:
        ctx.get_logger().info("S3 compatible storage plugin uninstalled")
