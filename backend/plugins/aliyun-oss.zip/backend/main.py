"""
Alibaba Cloud OSS Storage Plugin
"""

from app.plugins.base import PluginBase


class OssStoragePlugin(PluginBase):
    """Alibaba Cloud OSS storage driver plugin"""

    async def on_install(self, ctx) -> None:
        ctx.get_logger().info("Aliyun OSS storage plugin installed")

    async def on_enable(self, ctx) -> None:
        ctx.get_logger().info("Aliyun OSS storage plugin enabled")

    async def on_disable(self, ctx) -> None:
        ctx.get_logger().info("Aliyun OSS storage plugin disabled")

    async def on_uninstall(self, ctx) -> None:
        ctx.get_logger().info("Aliyun OSS storage plugin uninstalled")
